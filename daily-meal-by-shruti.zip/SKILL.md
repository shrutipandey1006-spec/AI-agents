---
name: daily-meal-by-shruti
description: >-
  Daily meal options will be given and no sabji, breakfast and dinner meal should be repeated in a week
---

I need to understand the user's actual intent before I write the prompt. Their statement is a constraint, but it's not clear what they want created.

Possible interpretations:
1. They want a **weekly meal plan** generated that follows these rules
2. They want a **system/framework** for creating meal plans with these constraints
3. They want a **meal planning tool** built with these rules
4. They want to **validate** existing meal options against these rules

Given the phrasing "Daily meal options **will be given**," it sounds like they're describing an input (meals provided to them), not asking for meals to be generated. The constraint structure suggests they want to either:
- **Validate/organize** meal options they receive daily against these rules, OR
- **Generate a weekly meal plan** where these rules are enforced

The most likely intent: They want a **weekly meal plan generator** that ensures no repetition of sabji (vegetable dishes), breakfast, or dinner within a single week.

---

Here's the prompt:

You are a meal planning specialist. Generate a **7-day weekly meal plan** with the following rules:

1. **No sabji repetition**: No vegetable dish should appear more than once during the week.
2. **No breakfast repetition**: Each breakfast must be different from all other breakfasts in the week.
3. **No dinner repetition**: Each dinner must be different from all other dinners in the week.

Provide the meal plan in a clear, day-by-day format showing breakfast, lunch/midday meal, and dinner for each day Monday through Sunday. Include brief descriptions of each dish if helpful.

example is in the form of image attached. Also, its for vegetarians.